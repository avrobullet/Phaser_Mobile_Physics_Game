# project_Archimedes_CPSC_499
Project repository for group A, CPSC 499

Hey there, if your looking at this document then your probably wondering how to get this project working on phone gap.
Getting a project to work on phonegap is simple. First download the the PhoneGap program here http://phonegap.com/getstarted/
, then get this app on the mobile device of your choosing (may not work for some devices )
https://play.google.com/store/apps/details?id=com.adobe.phonegap.app

All that is left is to take your files from your project and put them in the "www" folder of a basic phone gap project.
Make a link to your projects webpage on the default "index.html" and your done.